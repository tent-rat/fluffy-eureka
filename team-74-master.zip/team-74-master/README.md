# Team 74 Pico Zen 🌟🌟
# Code for Good JPMC 2022 🌱

![Collaborators](https://img.shields.io/badge/collaborators-7-red)
![Status](https://img.shields.io/badge/status-done-green)
![Issues](https://img.shields.io/badge/issues-0-blue)
[![made-with-Markdown](https://img.shields.io/badge/Made%20with-Markdown-1f425f.svg)](http://commonmark.org)
[![MIT license](https://img.shields.io/badge/License-MIT-blue.svg)](https://lbesson.mit-license.org/) 

## Code for Good 2022 ⚓

![Capture](https://user-images.githubusercontent.com/75165587/175798108-4ffd5af2-f45f-49b6-afc3-1bbe5c0705af.PNG)

## Problem Statement 🚧

### Organisational Problem Statement : Kotak Education Foundation DLS
![kotak-logo](https://user-images.githubusercontent.com/75165587/175798461-c0d691a1-5736-4838-803e-fdfa2a9fd99a.png)


From the Organization: 

Currently there is manual management of field data which leads to consumption of time. 
Loss of Data due to different ways of communication
Format in which the data is collected is Audio, Video, photos, ppts etc.
There is no way to track and see the progress of Teachers and the NGO working outcomes.
There is no way to recognize the efforts of Teacher's and boast their confidence.

## Background 📖
Kotak Education Foundation (KEF) was set up in 2007 with the intention to support children and youth from underprivileged families through different education based interventions and skill-training programs.
Kotak Education Foundation takes a holistic and innovative approach for helping the urban poor break free from the vicious cycle of extreme poverty and generational disadvantages. KEF has partnered with 200+ schools within Mumbai city.
KEF helps teachers with innovative teaching methods. They want to track under one platform whether these methods are being implemented in schools and whether students find it useful. They are currently struggling in centralized data management for different beneficiaries in the foundation.


## About Our project 🔧
### 🔈 What
**Our project** is a Moblie Application ( as the NGO wanted app specifically ) as well as a Web Application that enables it's teachers , teaching assistants to accesses the dashboard
Admins can access the details of TAs and TAs can track information of teachers under them.Teachers can upload videos, images, audios etc from their profile. The TA can then provide feedback for the particular submission.The homepage displays the features of the NGO. Using the login credentials, a user can access their respective dashboards. 

### 🔈 Why
It was really difficult for the teachers and the teaching assistants to upload and access all the resources as most of the times the resoures were getting lost and miss placed

### 🔈 How
With a super simple User Interface, Our project can be accessed as a mobile application and through the browser, giving users the flexibility to upload, analyse and operate.
The web app not just supports the feature for teachers to upload artefacts but also allows admins and teacher assistants to track the progress of each individual, conduct surveys and provide feedback.


## Timeline ⏰

- Day 1: Checkpoints ✏️:
   - [x] Documentation
   - [x] Set Up Front End
   - [x] Create a Chatbot 
   - [x] Implement UI/UX Principles
   - [x] explore ways to implement our idea
   - [x] - making the flutter app
   
- Day 2: Checkpoints ✏️:
   - [x] Integrate Front End and Back End
   - [x] Deploy over Cloud
   - [x] Run Checks
   - [x] Deploying and making the apk 

## Technology Principles Implemented 💡

1. Mobile ( Flutter )
2. Website ( MERN )
3.  Minimalist Design
4. Reusable
5. Well Documented
6. Open Source
7. Feasible
8. Scalable
9. Accessible To All

## Technology Stack 💻

- GitHub
- Flutter
- Mongodb
- Reactjs
- ExpressJs
- NodeJs
- Tenser Flow
  
### Attributions

- Collect.chat


## Collaborators 🤖

Only developers.
| Name      | GitHub Profile     |
| :------------- | :----------: |
|  Ruchika Suryawanshi       | [GitHub](https://github.com/RuchikaSuryawanshi7) |
|  Chetas Shree Madhusudhan   | [GitHub](https://github.com/ChetasShree) |
|  Rishab Bendukuri   | [GitHub](https://github.com/Rishab-Bendukuri) |
|  Vijitha Uppar  | [GitHub](https://github.com/upparvijitha) |
|  Siddharth Maurya   | [GitHub](https://github.com/SiddharthM69) |
|  Mouli Ghosh   | [GitHub](https://github.com/Mouli-16) |
|  Kuhuk Agarwal   | [GitHub](https://github.com/kuhuk521) |
