package com.example.kotak_edu_dls

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
