const express = require("express");
const app = express();
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const helmet = require("helmet");
const morgan = require("morgan");
const authRoute = require("./routes/admin");
const taRoute = require("./routes/teaching_assistance");
const assignmentRoute = require("./routes/assignments");
const router = express.Router();
const path = require("path");
const multer = require("multer");
const cors = require("cors");

dotenv.config();

app.use(cors());

app.use("/images", express.static(path.join(__dirname, "public/images")));

const fileStorageEngine = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "public/images"); //important this is a direct path fron our current file to storage location
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + "--" + file.originalname);
    },
  });

  const upload = multer({ storage: fileStorageEngine });

  app.post("/upload", upload.single("File"), (req, res) => {
    console.log(req.file);
    res.send("FIle upload success");
  });


mongoose.connect(process.env.dbURL,
    { useNewUrlParser: true, useUnifiedTopology:true},
    ()=>{
        console.log("Connected to DB");
    }
);


// middleware
app.use(express.json());
app.use(helmet())
app.use(morgan("common"));

app.use("/auth", authRoute);
app.use("/ta", taRoute);
app.use("/assignment", assignmentRoute);


app.listen(5700,()=>{
    console.log("Server Running");
})