const mongoose = require("mongoose")
const Schema = mongoose.Schema;

const AssignmentsSchema = new Schema({
    teacher_id:{
        type:String,
        required:true,
    },
    teacher_name:{
        type: String,
        required:true
    },
    heading:{
        type: String,
        required: true,
    },
    description:{
        type: String,
        required: true,
        max: 50,
    },
    filetype:{
        type: String,
        required: true
    },
    school:{
        type:String,
        required:true,
    },
    fileUpload:{
        type:String
    }
}, {timestamps: true})

module.exports = mongoose.model("Assignments", AssignmentsSchema)