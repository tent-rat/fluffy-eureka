const mongoose = require("mongoose")
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    name:{
        type: String,
        required: true,
    },
    email:{
        type: String,
        required: true,
        max: 50,
        unique: true,
    },
    role:{
        type: String,
        required: true
    },
    user_id:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type: String,
        required:true
    },
    school:{
        type:String,
        required:true,
        default:""
    },
    ta_id:{
        type:String
    }
}, {timestamps: true})

module.exports = mongoose.model("User", UserSchema)