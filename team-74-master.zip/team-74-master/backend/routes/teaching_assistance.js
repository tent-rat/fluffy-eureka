const router = require("express").Router();
const User = require("../models/User");
const bcrypt = require("bcrypt");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const { google } = require("googleapis");

CLIENT_ID = process.env.CLIENT_ID;
CLIENT_SECRET = process.env.CLIENT_SECRET;
REDIRECT_URI = process.env.REDIRECT_URI;
REFRESH_TOKEN = process.env.REFRESH_TOKEN;
const oAuth2Client = new google.auth.OAuth2(
  CLIENT_ID,
  CLIENT_SECRET,
  REDIRECT_URI
);
oAuth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

router.post("/register_teacher/:id", async (req, res) => {
  try {
      const taId = req.params.id 
      console.log(taId);
      const user_id = crypto.randomBytes(4).toString("hex");
      console.log(user_id);
      const password = crypto.randomBytes(4).toString("hex");
      console.log(password);
      const salt = await bcrypt.genSalt(10);
      hashedpassword = await bcrypt.hash(password, salt);
      const newUser = new User({
        name: req.body.name,
        email: req.body.email,
        school: req.body.school,
        user_id: user_id,
        password: hashedpassword,
        role: "t",
        ta_id:taId
      });

      //  save user
      const user = await newUser.save();
      let accessToken = await oAuth2Client.getAccessToken();
      console.log(oAuth2Client);

      let transport = nodemailer.createTransport({
        service: "gmail",
        auth: {
          type: "OAuth2",
          user: "subrolinaghosh@gmail.com",
          clientId: CLIENT_ID,
          clientSecret: CLIENT_SECRET,
          refreshToken: REFRESH_TOKEN,
          accessToken: accessToken,
        },
        tls: {
          rejectUnauthorized: false,
        },
      });
      let info = await transport.sendMail({
        from: '"KOTAK-DAL" <subrolinaghosh@gmail.com>',
        to: user.email,
        subject: "Registration confirmation",
        text: ``,
        html: `Greetings <b>${user.name}</b>,<br/><br/>Hers's your USER_ID :${user.user_id}</b>.<br/>And your PASSWORD :${user.password}</b>.<br/>`,
      });
      console.log("Message sent: %s", info.messageId);
      console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
      res.status(200).send(user);
  } catch (err) {
    res.status(500).json(err);
  }
});

// LOGIN

router.post("/login_teacher", async (req, res) => {
  try {
    const user = await User.findOne({
      user_id: req.body.user_id,
    });
    !user && res.status(404).json("user not found");
    const validPassword = await bcrypt.compare(
      req.body.password,
      user.password
    );
    !validPassword && res.status(400).json("wrong password");

    res.status(200).json(user);
  } catch (err) {
    res.status(500).json(err);
  }
});


// GET ALL TEACHERS
router.get("/teachers/:id", async(req,res)=>{
    try{
        const ta = req.params.id;
        const teachers = await User.find({
            ta_id: ta
        })
        let teachersList = [];
        teachers.map(teacher=>{
            teachersList.push(teacher)
        })
         res.status(200).json(teachersList)
    }catch(err){
        res.status(500).json(err)
    }
})

module.exports = router;
