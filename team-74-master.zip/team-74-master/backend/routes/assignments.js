const router = require("express").Router();
const Assignments = require("../models/Assignments");
const User = require("../models/User");





router.post("/submit/:id", async (req,res) => {
    try{
        const teacher = await User.findOne({
            user_id: req.params.id
        })
        const newAssignment = new Assignments({
            teacher_id:teacher.user_id,
            teacher_name:teacher.name,
            school:teacher.school,
            heading:req.body.heading,
            description:req.body.description,
            filetype:req.body.filetype,
            fileUpload:req.body.fileUpload
        });

        // console.log(newAssignment);
        //  save assignment
        const assignment = await newAssignment.save();
        res.status(200).send(assignment)
    } catch(err){
        res.status(500).json(err);
    }
    
})

router.get("/:id", async (req,res) => {
    try{
        const assignment = await Assignments.findOne({
            teacher_id: req.params.id
        })
        res.status(200).send(assignment)
    } catch(err){
        res.status(500).json(err);
    }
    
})
module.exports = router