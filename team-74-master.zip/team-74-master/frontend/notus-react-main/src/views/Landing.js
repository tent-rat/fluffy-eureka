import React from 'react'
import { SliderData } from 'components/Slider/SliderData'
import ImageSlider from 'components/Slider/ImageSlider'

import ParticlesBg from 'particles-bg';
function Landing() {
  return (
    <div>
      <ParticlesBg type="circle" bg={true} />
    </div>
  )
}

export default Landing