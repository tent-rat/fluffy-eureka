import React from 'react'


function Home() {
  return (<>Helloo from home</>
  )
}

export default Home